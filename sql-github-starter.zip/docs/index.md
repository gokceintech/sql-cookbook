# SQL Cookbook & Playbook

Welcome! This site documents the patterns used in this repository.

## Sections
- [PostgreSQL Patterns](cheat-sheets/postgres.md)
- [MySQL Patterns](cheat-sheets/mysql.md)

> The source of these docs lives in `/docs` and is auto-published with GitHub Pages.
