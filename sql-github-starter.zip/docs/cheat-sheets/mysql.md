# MySQL Patterns

- **Top customers (last 365 days)** — see `sql/mysql/queries/top_customers.sql`.
- **InnoDB tips** — PK is clustered; keep it narrow; add covering indexes for frequent lookups.
