# Contributing

Thanks for helping improve the SQL Cookbook & Playbook!

## How to add a new query
1. Pick a DB folder: `sql/postgres` or `sql/mysql`.
2. Add your `.sql` file under `queries/`. Start it with a header comment:
   ```sql
   -- name: short-title
   -- purpose: short description of the query
   -- notes: any assumptions, indices, or tuning tips
   ```
3. If a new table is needed, add it to `schema/` and insert a few rows of demo data.
4. Run `sqlfluff lint` with the correct `--dialect` and ensure it passes.
5. Run the integration tests locally or push a PR to let CI run them.
6. Update `/docs` if the query is a new pattern or technique.

## Code style
- Keep queries readable (CTEs for steps, clear aliases).
- Use explicit column lists (`SELECT specific_cols`), avoid `SELECT *` in examples.
- Index hints: create the smallest index that supports the WHERE/JOIN clauses.
- Prefer `EXPLAIN`/`EXPLAIN ANALYZE` locally when optimizing.

## PR checklist
- [ ] SQLFluff passes for the relevant dialect
- [ ] Query runs successfully on the demo data
- [ ] Documented in `/docs` if applicable
- [ ] Tests updated (or added) if schema changed
