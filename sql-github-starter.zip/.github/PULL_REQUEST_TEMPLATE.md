## Summary
- [ ] Linted with sqlfluff
- [ ] Query runs on demo data
- [ ] Docs updated (if applicable)

Closes #<issue-number>
